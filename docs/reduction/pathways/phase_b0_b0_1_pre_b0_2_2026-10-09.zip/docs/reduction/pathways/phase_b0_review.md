# Phase B0-1 executed review

Scientific status: **PENDING_HUMAN_REVIEW**. Phase B1 authorized: **false**.

Execution: `COMPLETED`; overall engineering: `PASS`. These results certify conditional finite source structure only.

## Repository and review hold

Machine: sean. Repository: `C:\Users\sean\Desktop\GUV`. Origin: `https://github.com/DrWanSJ/PURE.git`. Branch: `codex/energy-cycles-v1`.

Starting HEAD and ending HEAD: `14c61055775421e9f30342507cc4fffdceed1607` / `14c61055775421e9f30342507cc4fffdceed1607`. Startup fetch confirmed clean tree and upstream 0/0. Commit/push: `NOT_ATTEMPTED — B0-1 review hold`.

## Executed gates

| Gate | Status | Executed entrypoint | Evidence |
|---|---|---|---|
| A — Source Integrity | PASS | `python scripts/pathways/phase_b0/verify_phase_b0_witnesses.py` | `phase_b0_independent_verification.json` |
| B — W1 Structural Handoff | PASS | `python scripts/pathways/phase_b0/verify_phase_b0_witnesses.py` | `phase_b0_independent_verification.json` |
| C — W2 Multi-Precursor / Alternative Entry | PASS | `python scripts/pathways/phase_b0/verify_phase_b0_witnesses.py` | `phase_b0_independent_verification.json` |
| D — W3 Formylated-tRNA Handoff | PASS | `python scripts/pathways/phase_b0/verify_phase_b0_witnesses.py` | `phase_b0_independent_verification.json` |
| E — Net Stoichiometry | PASS | `python scripts/pathways/phase_b0/verify_phase_b0_witnesses.py` | `phase_b0_independent_verification.json` |
| F — Negative Controls | PASS | `python scripts/pathways/phase_b0/test_phase_b0_negative_controls.py` | `phase_b0_negative_controls.json` |
| G — Phase A Regression / Preservation | PASS | `python scripts/pathways/verify_pathway_atlas.py; python scripts/pathways/phase_b0/run_phase_b0_validation.py` | `phase_b0_phase_a_regression.json; phase_b0_html_regression.json` |

## Witness results

| Witness | Directed occurrences | Exact structural net | Verification |
|---|---|---|---|
| W1 | 10 | `ATP + EFTu_GTP + Gly + elRS70SAGGU0002_fMet + tRNAGlyGCC -> AMP + PPi + elRS70SAGGU0002_fMet_EFTu_GTP_GlytRNAGlyGCC` | PASS |
| W2 | 13 | `ATP + FD + Met + tRNAfMetCAU -> AMP + PPi + THF + fMettRNAfMetCAU` | PASS |
| W3 | 14 | `ATP + FD + IF2_GTP + Met + tRNAfMetCAU -> AMP + IF2_GTP_fMettRNAfMetCAU + PPi + THF` | PASS |
| W2-MTF | 5 | `FD + MettRNAfMetCAU -> THF + fMettRNAfMetCAU` | PASS |
| W2-ALT | 13 | `ATP + FD + Met + tRNAfMetCAU -> AMP + PPi + THF + fMettRNAfMetCAU` | PASS |

Required negatives: 12 run, 12 passed, 0 failed. All negatives including supplements: 18 run, 18 passed, 0 failed.

| Control | Expected rejection | Actual rejection | Petri enabling | Result |
|---|---|---|---|---|
| N01 | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | PASS |
| N02 | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | PASS |
| N03 | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | PASS |
| N04 | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | PASS |
| N05 | CARRIER_LINEAGE_MISMATCH | CARRIER_LINEAGE_MISMATCH | PASS | PASS |
| N06 | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | PASS |
| N07 | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | PASS |
| N08 | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | MISSING_REQUIRED_INPUT | PASS |
| N09 | SHARED_RESOURCE_NOT_CARRIER | SHARED_RESOURCE_NOT_CARRIER | PASS | PASS |
| N10 | REFERENCE_ACTIVITY_MISMATCH | REFERENCE_ACTIVITY_MISMATCH | PASS | PASS |
| N11 | DUPLICATE_OCCURRENCE | DUPLICATE_OCCURRENCE | MISSING_REQUIRED_INPUT | PASS |
| N12 | SOURCE_COEFFICIENT_MISMATCH | SOURCE_COEFFICIENT_MISMATCH | NOT_APPLICABLE | PASS |
| S01 | NET_STOICHIOMETRY_MISMATCH | NET_STOICHIOMETRY_MISMATCH | PASS | PASS |
| S02 | EVENT_DAG_MISMATCH | EVENT_DAG_MISMATCH | PASS | PASS |
| S03 | FALSE_CYCLE_CLAIM | FALSE_CYCLE_CLAIM | PASS | PASS |
| S04 | TOKEN_PROVENANCE_MISMATCH | TOKEN_PROVENANCE_MISMATCH | PASS | PASS |
| S05 | CATALYST_NOT_RECOVERED | CATALYST_NOT_RECOVERED | PASS | PASS |
| S06 | REQUIRED_CARRIER_HANDOFF_MISSING | REQUIRED_CARRIER_HANDOFF_MISSING | PASS | PASS |

Supplemental positives verify a reordered independent precursor and two genuine MTF cycles with distinct occurrences (each source direction counted twice). N05 is Petri-enabled but rejected for carrier lineage. N09 is Petri-enabled but rejected for a shared-resource carrier claim. All mutations are in memory; none alters source files.

## Independent evidence and preservation

The verifier imports no builder. It reparses original MathML, independent author CSV values and archive bytes, checks exact signed nets, every input and token origin, DAG edges, catalyst recovery, boundary balances, alternative rejoin and reference directions. All five source-bound scenarios are independently checked. The generated witness records retain CANDIDATE_AWAITING_INDEPENDENT_VERIFICATION; executed outcomes live in separate validation reports.

All 2342 pre-existing tracked files are byte-unchanged. Phase A mutation/report writes used temporary copies. Existing HTML regression functions ran read-only with all new reports routed to B0.

Source hashes:

- `docs/reduction/reaction_level_annotation_v2.csv`: `ee2f80a3354199a03d3072464cbc301736afad72fba01e4bfcc499c0525f3335`.
- `models/pnas2017_full_reference/original/fMGG_synthesis.xml`: `dc43bcec367f52105fe8d1ba328e59b064935df5faf8f880e078b212a40183df`.
- `models/pnas2017_full_reference/original/simulate/Simulate_fMGG_synthesis/dat/fMGG_synthesis_parameters.csv`: `cfb24e2cb9f70168e30355d51dd4a4036686ceefab1a2b26bac122448c81b465`.
- `references/PNAS2017_Matsuura/raw/Simulate_fMGG_synthesis.zip`: `beb27ebbd314133fbd83f68dcf8ad2ebe08cb16a1adda170b6b7b408ad355b52`.

Two independent builder runs reproduce both new deterministic witness files and equal delivered SHA-256 values:

- `phase_b0_handoff_witnesses.json`: `2fb1f8c98f3d11568493941f071fc6e7ae2a44ea25a645a670fdbd21ec4088e0`.
- `phase_b0_handoff_witnesses.md`: `04c3cd9f251dabb25ada0ea5e3b0bfade2f2878abeb1ff421e8358f9461a52a8`.

## Reproduction commands

From the repository root, using the existing Python environment:

```powershell
python scripts/pathways/phase_b0/build_phase_b0_witnesses.py
python scripts/pathways/phase_b0/verify_phase_b0_witnesses.py
python scripts/pathways/phase_b0/test_phase_b0_negative_controls.py
python scripts/pathways/verify_pathway_atlas.py
python scripts/pathways/phase_b0/run_phase_b0_validation.py
```

The final command safely runs Phase A mutation tests in a temporary copy, existing HTML acceptance functions, two B0 builds and preservation checks. Do not run old report-writing mutation/browser entrypoints with default output paths: that would overwrite archived Phase A results. Exact executed temporary paths, raw outputs and exit codes are in phase_b0_execution_log.txt and the regression reports.

## Limitations, failures and unresolved questions

All selected positive directions have nonzero reference parameters; 0427 remains an original zero-parameter reverse in the context appendix. Nonzero k is not measured flux. Finite boundary supplies are explicit conditional assumptions. No full-network availability, complex molecular composition, binding-order dominance, completed elongation/initiation, kinetic feasibility, QSSA, effective-rate law or reduced model is approved.

phase_b0_failure_evidence.jsonl preserves genuine failed attempts. An initial inspection used Windows' default GBK decoding for UTF-8 JSON and failed; it was rerun with explicit UTF-8 without source modification. Any later actual failures are appended with their raw evidence. Expected negative rejections are recorded separately and do not represent failed acceptance gates.

## B0-2 researcher review

1. W1 的 elRS70SAGGU0002_fMet 与 EFTu_GTP 均为显式外部供给，终点为核糖体结合复合物。是否接受它作为结合接口证据，并继续把上游核糖体形成与完整延伸保留为未验证？
2. 是否接受 MTF 的 FD-first (0418/0422) 与 Met-tRNA-first (0420/0424) 为互相竞争的有限入口，并在 MTF_FD_MettRNAfMetCAU 真正汇合，不推断优势结合顺序？
3. 源模型 0426 的复合物转化、0428 的产物释放和 0434 的 MTF 回收已分开记录。是否接受这一来源层面的甲酰化解释，同时保持 FD 的化学身份未获额外证实？
4. W3 由 W2 生成的精确 fMettRNAfMetCAU 接入 0449，IF2_GTP 显式外供且 0445 未纳入核心见证。是否接受这个 IF2 结合终点，并将核糖体起始与 IF2 回收留待后续独立研究？
5. 源物种流向已验证，但跨 GlyRS/tRNA/EF-Tu、MetRS/tRNA/MTF/IF2 和核糖体复合物的分子身份投影仍为 INFERRED。后续工作需要何种论文/注释证据才可批准这些身份规则？

## B0-2 handoff checklist

- Review actual W1–W3 equations, boundary assumptions, exact handoffs and provisional carrier streams.
- Record the five scientific decisions above as researcher decisions, retaining any UNRESOLVED identity questions.
- Preserve the executed positive/negative, source hash, failure and regression evidence.
- Obtain explicit authorization before commit/push; this local review hold remains active.
- Obtain separate scope authorization before any Phase B1 reconstruction or kinetic work.

B0-1 stops here. No Phase B1, commit or push was attempted.
