# Proposed provenance synchronization repair — 2026-10-02

This proposal has not been applied to the repository. It repairs two stale provenance checks caused by the already committed human-approved documentation change, without changing the G1 scientific criteria or any source/model data.

## Evidence of the mismatch

- The preserved `docs/reduction/review_render_manifest.json` records the original renderer output SHA-256 `ef9f617cf9121200c52c14f00f17c86d96e48793377464b89414a631e75c1de7` for `human_reduction_review.md`.
- Main commit `d5874dec053e6ff210e3d1843bb7735ebe3ba84a`, dated 2026-09-30, changed only that document to distinguish completed species retention from pending reaction/process reduction choices. Its exact output SHA-256 is `b32dcbfa155be5d77411691889e67da7a6a89c7d87ba1406171e74db6c95c2d8`.
- The integration verifier still compares this documentation file with baseline `0a72448ff20db8e58593a9910b8944c121750778`. The ten remaining canonical/model/inventory/decision artifacts still match that baseline.

## Proposed files

1. Add `docs/reduction/review_sync_manifest_20260930.json`: bind the preserved historical render manifest, old rendered review, exact approved review commit/output, and three approved information-contract support documents from reaffirmation commit `678fcb709324142454fd7a80cb6185c64b900510`.
2. Update `scripts/verify_pnas2017_artifacts.py`: keep original renderer fingerprints for all other outputs; verify this one documentation change through the new exact transition record. Reject another commit, altered review, altered historical manifest, or altered information contract. Both approved commits must be ancestors of current HEAD. The approved synchronization commit must have changed only the review document.
3. Update `scripts/verify_pnas2017_integration.py`: retain its historical source baseline for all ten remaining frozen files; verify this one review file against the same approved documentation transition. Keep the existing check names/count and source/candidate integrity checks.

The three support Markdown documents use native CRLF checkout bytes but LF Git blobs. Their record explicitly declares CRLF-to-LF canonicalization for those Markdown references only. Raw sources, generated source artifacts, the review itself, and the historical render manifest remain exact-byte checked.

## Preservation and boundary

The patch does not edit `review_render_manifest.json`, the old integration baseline, the SBML, CSV source/model/ledger/decision data, current human-review prose, scientific acceptance criteria, or thresholds. It does not regenerate historical data or select a kinetic reduction. The existing failure outputs remain preserved. The new record explains the already approved change rather than replacing its prior evidence.

## Reviewable artifacts

- Patch: `provenance_sync_proposal.patch`
- Proposed full files: `provenance_sync_proposed_files/`
- External dry-run checker: `verify_proposed_sync.py`
- External test results: `provenance_sync_proposal_checks.json` (created after checks finish)

All work is confined to `C:\Users\sean\.codex\tmp\g1-pnas-20261002`. Applying the proposal to main requires separate authorization because the original task forbids modifying verifier evidence to obtain a pass. This is a provenance-only exception proposal; the ten G1 criteria remain unchanged.
