"""Read-only main-source diagnostics; does not replace repository verifiers."""
from pathlib import Path
import collections, csv, hashlib, importlib.util, json, subprocess, sys, zipfile

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(__file__).resolve().parent
def sha(content): return hashlib.sha256(content).hexdigest()
def data(rel): return (ROOT / rel).read_bytes()
def rows(rel):
    with (ROOT / rel).open(encoding='utf-8', newline='') as stream: return list(csv.DictReader(stream))
def blob(rev, rel): return subprocess.check_output(['git', 'show', f'{rev}:{rel}'], cwd=ROOT)

evidence = {'repository_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
manifest = rows('references/PNAS2017_Matsuura/provenance/source_manifest.csv')
sources = []
for item in manifest:
    path = 'references/PNAS2017_Matsuura/raw/' + item['filename']
    value = data(path)
    sources.append({'path':path,'bytes':len(value),'sha256':sha(value),'expected_bytes':int(item['bytes']),'expected_sha256':item['sha256'],'match':len(value)==int(item['bytes']) and sha(value)==item['sha256']})
evidence['source_manifest'] = {'count':len(sources),'all_match':all(i['match'] for i in sources),'files':sources}
extracted = []
for archive_name, dest in [('SBML_files.zip','models/pnas2017_full_reference/original/subsystems'),('Simulate_fMGG_synthesis.zip','models/pnas2017_full_reference/original/simulate')]:
    with zipfile.ZipFile(ROOT/'references/PNAS2017_Matsuura/raw'/archive_name) as archive:
        for member in archive.namelist():
            if member.endswith('/'): continue
            target = ROOT / dest / (Path(member).name if archive_name=='SBML_files.zip' else member)
            if not target.is_file(): continue
            value = archive.read(member)
            extracted.append({'archive':archive_name,'member':member,'path':target.relative_to(ROOT).as_posix(),'bytes':len(value),'sha256':sha(value),'match':target.read_bytes()==value})
evidence['extracted_original_archive_members']={'count':len(extracted),'all_match':all(i['match'] for i in extracted),'files':extracted}
inventory = []
for name in ['species','reactions','parameters','modules']:
    rel = f'models/pnas2017_full_reference/audit/{name}.csv'
    registered = data(rel)
    fresh = (OUT/'regenerated_audit'/f'{name}.csv').read_bytes()
    inventory.append({'path':rel,'rows':len(rows(rel)),'bytes':len(registered),'sha256':sha(registered),'fresh_sha256':sha(fresh),'byte_identical':registered==fresh})
evidence['regenerated_inventory_comparison']=inventory
initial = rows('models/pnas2017_full_reference/original/simulate/Simulate_fMGG_synthesis/dat/fMGG_synthesis_initial_values.csv')
evidence['author_initial_conditions']={'total_rows':len(initial),'positive_count':sum(float(r['Value'])>0 for r in initial),'positive_original_names':[r['Name'] for r in initial if float(r['Value'])>0]}

spec=importlib.util.spec_from_file_location('current_audit', ROOT/'scripts/audit_pnas2017_sbml.py')
audit=importlib.util.module_from_spec(spec); spec.loader.exec_module(audit)
import libsbml
original=libsbml.readSBML(str(ROOT/'models/pnas2017_full_reference/original/fMGG_synthesis.xml'))
normalized=libsbml.readSBML(str(ROOT/'models/pnas2017_full_reference/normalized/fMGG_synthesis_constant_stoichiometry.xml'))
evidence['libsbml']={'version':libsbml.getLibSBMLDottedVersion(),'parse_messages':original.getNumErrors()}
count, grouped = audit.validation_summary(original)
messages=[{'id':original.getError(i).getErrorId(),'severity':original.getError(i).getSeverityAsString(),'category':original.getError(i).getCategoryAsString(),'line':original.getError(i).getLine(),'message':original.getError(i).getMessage()} for i in range(original.getNumErrors())]
message_path=OUT/'libsbml_messages_fresh.json'
message_path.write_text(json.dumps(messages,indent=2)+'\n',encoding='utf-8',newline='\n')
evidence['libsbml'].update({'consistency_count':count,'groups':grouped,'message_path':str(message_path),'message_sha256':sha(message_path.read_bytes())})
model=original.getModel(); norm=normalized.getModel()
evidence['source_model']={'model_id':model.getId(),'level':original.getLevel(),'version':original.getVersion(),'species':model.getNumSpecies(),'reactions':model.getNumReactions(),'local_parameters':sum(r.getKineticLaw().getNumParameters() for r in model.getListOfReactions()),'global_parameters':model.getNumParameters(),'unit_definitions':model.getNumUnitDefinitions(),'positive_initial_species':sum(s.getInitialConcentration()>0 for s in model.getListOfSpecies()),'all_local_values_one':all(p.getValue()==1 for r in model.getListOfReactions() for p in r.getKineticLaw().getListOfParameters())}
evidence['normalized_equivalence']={'species_original_ids_identical':[s.getId() for s in model.getListOfSpecies()]==[s.getId() for s in norm.getListOfSpecies()],'reaction_original_ids_identical':[r.getId() for r in model.getListOfReactions()]==[r.getId() for r in norm.getListOfReactions()],'every_reaction_signature_identical':all(audit.reaction_signature(r)==audit.reaction_signature(norm.getReaction(r.getId())) for r in model.getListOfReactions()),'source_math_reference_count':sum(ref.isSetStoichiometryMath() for r in model.getListOfReactions() for refs in [r.getListOfReactants(),r.getListOfProducts()] for ref in refs),'normalized_math_reference_count':sum(ref.isSetStoichiometryMath() for r in norm.getListOfReactions() for refs in [r.getListOfReactants(),r.getListOfProducts()] for ref in refs)}
evidence['stoichiometry_re0000000414_PO4']={'source':audit.reference_rows(model.getReaction('re0000000414').getListOfProducts()),'normalized':audit.reference_rows(norm.getReaction('re0000000414').getListOfProducts())}

# Independent post-failure assertions from the existing artifact verifier.
# The official failing verifier result remains a failure.
spec=importlib.util.spec_from_file_location('current_artifacts',ROOT/'scripts/verify_pnas2017_artifacts.py')
art=importlib.util.module_from_spec(spec); spec.loader.exec_module(art)
checks=[]
def assertion(label, fn):
    try: fn(); checks.append({'check':label,'status':'PASS'})
    except Exception as exc: checks.append({'check':label,'status':'FAIL','error':repr(exc)})
review=json.loads(data('docs/reduction/review_render_manifest.json'))
assertion('review_input_registered_hashes',lambda:art.registered_hashes(review['inputs_sha256'],'review input'))
assertion('review_output_registered_hashes_OFFICIAL_FAILURE_RETAINED',lambda:art.registered_hashes(review['outputs_sha256'],'review output'))
text=data('docs/reduction/human_reduction_review.md').decode('utf-8')
checks.append({'check':'review_cards_and_choices','status':'PASS' if review['counts']['combined_reactions']==968 and review['counts']['process_review_cards']==16 and '[x]' not in text.lower() and text.count('[ ] KEEP')==16 else 'FAIL','review_cards':text.count('[ ] KEEP'),'checked_boxes':text.lower().count('[x]')})
run=json.loads(data('results/pnas2017_reference/rr_cvode_author_csv_20260924/run_manifest.json'))
assertion('preserved_run_sources',lambda:art.registered_hashes(run['source_sha256'],'run source'))
checks.append({'check':'preserved_effective_author_conditions','status':'PASS' if art.sha(run['effective_author_conditions_sbml']['path'])==run['effective_author_conditions_sbml']['sha256'] else 'FAIL'})
checks.append({'check':'preserved_trajectory','status':'PASS' if art.sha(run['trajectory']['path'])==run['trajectory']['sha256'] else 'FAIL'})
comparison=json.loads(data('results/pnas2017_reference/rr_cvode_author_csv_20260924/engine_comparison.json'))
assertion('preserved_comparison_inputs',lambda:art.registered_hashes(comparison['source_files_sha256'],'comparison source'))
checks.append({'check':'comparison_diagnostic_status','status':'PASS' if comparison['status']=='ENGINE_COMPARISON_DIAGNOSTIC_NO_PREREGISTERED_PASS_THRESHOLD' else 'FAIL'})
evidence['artifact_post_failure_diagnostics']=checks
path='docs/reduction/human_reduction_review.md'
current=data(path); head=blob('HEAD',path); old=blob('d5874dec053e6ff210e3d1843bb7735ebe3ba84a^',path)
evidence['review_manifest_diagnosis']={'official_verifier_exit':1,'manifest_expected_sha256':review['outputs_sha256'][path],'worktree_sha256':sha(current),'head_blob_sha256':sha(head),'pre_sync_sha256':sha(old),'worktree_equals_head_blob':current==head,'worktree_crlf':current.count(b'\r\n'),'head_blob_crlf':head.count(b'\r\n'),'semantic_change_commit':'d5874dec053e6ff210e3d1843bb7735ebe3ba84a','current_bytes':len(current),'pre_sync_bytes':len(old)}
evidence_path=OUT/'source_evidence.json'
evidence_path.write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'evidence_path':str(evidence_path),'evidence_sha256':sha(evidence_path.read_bytes()),'source_files':len(sources),'source_all_match':all(i['match'] for i in sources),'extracted_original_archive_members':len(extracted),'all_regenerated_inventory_bytes_match':all(i['byte_identical'] for i in inventory),'author_positive_initials':evidence['author_initial_conditions']['positive_count'],'normalized_equivalence':evidence['normalized_equivalence'],'libsbml_message_count':len(messages),'post_failure_assertions':checks},indent=2))
