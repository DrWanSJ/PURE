from pathlib import Path
import json, hashlib, openpyxl, sys
root = Path(sys.argv[1]) / 'references/PNAS2017_Matsuura/raw'
items = []
for i in range(1,30):
    path=root/f'pnas.1615351114.sd{i:02d}.xlsx'
    book=openpyxl.load_workbook(path,read_only=True,data_only=False)
    items.append({'filename':path.name,'signature':path.read_bytes()[:4].hex(),'sheets':[{'name':s.title,'rows':s.max_row,'columns':s.max_column} for s in book.worksheets]})
    book.close()
pdf=next(root.glob('*.pdf'))
result={'openpyxl':openpyxl.__version__,'workbooks_opened':len(items),'workbooks':items,'article_pdf_signature':pdf.read_bytes()[:8].decode('ascii')}
out=Path(__file__).resolve().parent/'publisher_format_evidence.json'
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'workbooks_opened':len(items),'pdf_signature':result['article_pdf_signature'],'S27':items[26],'S28':items[27]},indent=2))
