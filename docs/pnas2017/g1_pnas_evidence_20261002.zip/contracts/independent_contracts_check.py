import csv, hashlib, json, re
from collections import Counter
from pathlib import Path

root=Path(r'C:\Users\sean\.codex\worktrees\g1-pnas-closure\GUV')
out=Path(r'C:\Users\sean\.codex\tmp\g1-pnas-20261002\contracts')
def rows(rel):
    with (root/rel).open(encoding='utf-8',newline='') as f: return list(csv.DictReader(f))
def load(rel): return json.loads((root/rel).read_text(encoding='utf-8'))
def count(items): return dict(sorted(Counter(items).items()))
def ids_exact(data,key,source):
    ids=[r[key] for r in data]
    assert len(ids)==len(set(ids))==len(source)
    assert set(ids)==source

species=rows('models/pnas2017_full_reference/audit/species.csv')
reactions=rows('models/pnas2017_full_reference/audit/reactions.csv')
source_s={r['species_id'] for r in species}
source_r={r['reaction_id'] for r in reactions}
assert len(source_s)==241 and len(source_r)==968
props=rows('models/pnas2017_full_reference/audit/species_properties.csv')
balance=rows('models/pnas2017_full_reference/audit/reaction_balance_audit.csv')
smap=rows('models/pnas2017_full_reference/audit/species_reduction_map.csv')
decisions=rows('docs/reduction/reduction_decisions.csv')
ids_exact(props,'sbml_id',source_s)
ids_exact(smap,'species_id',source_s)
ids_exact(balance,'sbml_reaction_id',source_r)
ids_exact(decisions,'sbml_reaction_id',source_r)

annotation={}
for version in ['v0','v1','v2']:
    rr=rows(f'docs/reduction/reaction_level_annotation_{version}.csv')
    ids_exact(rr,'reaction_id',source_r)
    assert all(r['level_a_module_candidates'] and r['level_b_subsystem_candidates'] for r in rr)
    annotation[version]={'rows':len(rr),'unique_source_ids':len({r['reaction_id'] for r in rr})}
    if version=='v0':
        man=load('docs/reduction/reaction_level_annotation_manifest_v0.json')
        assert count(r['annotation_confidence'] for r in rr)==man['confidence_counts']
        assert count(r['level_c_functional_stage'] for r in rr)==man['level_c_directed_counts']
        assert count(r['mechanistic_reaction_type'] for r in rr)==man['mechanistic_type_counts']
        assert sum(r['reversibility_class']=='EXACT_REVERSE_PAIR' for r in rr)==man['exact_reverse_directed_rows']==580
        assert sum(r['level_c_functional_stage']=='DEG_sink' for r in rr)==man['degradation_rows']==388
        assert {r['reaction_id'] for r in rr if r['annotation_confidence']=='low'}==set(man['low_confidence_reaction_ids'])
        by={r['reaction_id']:r for r in rr}
        for r in rr:
            if r['reverse_partner_id']:
                p=by[r['reverse_partner_id']]
                assert p['reverse_partner_id']==r['reaction_id'] and p['level_c_functional_stage']==r['level_c_functional_stage']
        annotation[version]['confidence_counts']=count(r['annotation_confidence'] for r in rr)
        annotation[version]['directed_stage_counts']=count(r['level_c_functional_stage'] for r in rr)
    if version=='v2':
        counts=count(r['functional_annotation_status'] for r in rr)
        expected={'DIRECT_CHEMISTRY':492,'GRAPH_PROPAGATED':50,'REFERENCE_DISABLED':420,'SHARED_JUNCTION':6}
        assert counts==expected
        assert all(r['human_functional_review_required']=='false' for r in rr)
        assert len(rows('docs/reduction/human_functional_review_queue_v2.csv'))==0
        fam=rows('docs/reduction/reaction_family_summary_v2.csv')
        annotation[version].update(status_counts=counts,functional_annotation_unresolved=0,live_review_rows=0,families=len(fam))

detail=(root/'docs/reduction/species_information_contract_detailed.md').read_text(encoding='utf-8')
parsed=re.findall(r'^\|\s*(\d+)\s*\|\s*`([^`]+)`\s*\|.*?\|\s*\*\*(I|II-A|II-B|III|C)\*\*\s*\|',detail,re.M)
assert len(parsed)==241 and {s for _,s,_ in parsed}==source_s
assert len({s for _,s,_ in parsed})==241
assert {int(n) for n,_,_ in parsed}==set(range(1,242))
cls={s:c for _,s,c in parsed}
expected={'I':42,'II-A':57,'II-B':91,'III':22,'C':29}
assert count(cls.values())==expected
summary=(root/'docs/reduction/species_information_contract_summary.md').read_text(encoding='utf-8')
summary_ids={}
for line in summary.splitlines():
    m=re.match(r'^\| \*\*(I|II-A|II-B|III|C) ',line)
    if m:
        listed=[t for t in re.findall(r'`([^`]+)`',line) if t in source_s]
        assert len(listed)==len(set(listed))==expected[m[1]]
        summary_ids[m[1]]=set(listed)
assert set(summary_ids)==set(expected)
for c,ss in summary_ids.items(): assert ss=={s for s,v in cls.items() if v==c}
assert 'human-approved species-level classification v1' in summary
assert 'human-approved species-level classification v1' in detail

resources=['ATP','ADP','AMP','GTP','GDP','GMP','PO4','PPi','CP','Cr','Gly','Met','fMet','tRNAGlyGCC','tRNAfMetCAU','GlytRNAGlyGCC','MettRNAfMetCAU','fMettRNAfMetCAU','RS30S','RS50S','RS70S','IF1','IF2','IF3','EFG','EFTs','EFTu','RF1','RF2','RF3','RRF','GlyRS','MetRS','CK','MK','NDK','PPiase','mRNA','Pept0003']
assert set(resources)<=source_s
assert all(cls[s]=='I' for s in resources)
assert not ({'NTP','NXP'} & source_s)
assert cls['Pept0002tRNAGlyGCC']==cls['Pept0003tRNAGlyGCC']=='II-B'
assert all(not r[k] for r in props for k in ['formula','net_charge','charge_protonation_convention'])
assert all(r['formula_charge_provenance']=='UNRESOLVED' for r in props)
assert all('inferred' in r['reference_initial_unit_status'] and 'omits unit metadata' in r['reference_initial_unit_status'] for r in props)
assert sum(float(r['reference_initial_concentration'])>0 for r in props)==27
assert all(r['ionic_strength_status']=='UNAVAILABLE_CHARGE_PROTONATION_MG_BINDING_ABSENT' for r in balance)
assert all(r['elemental_balance_status']=='UNRESOLVED_FORMULAS_ABSENT' for r in balance)
assert all(r['moiety_balance_status']=='UNRESOLVED_BOUND_MOIETIES_NOT_ANNOTATED' for r in balance)

sinks={s for s,c in cls.items() if c=='C'}
reactant_sinks=set()
source_by={r['reaction_id']:r for r in reactions}
free_keys=[k for k in balance[0] if k.startswith('net_free_')]
for r in balance:
    reactants=json.loads(r['reactants_json']); products=json.loads(r['products_json'])
    source_reactants={p['species_id']:float(p['stoichiometry']) for p in json.loads(source_by[r['sbml_reaction_id']]['reactants_json'])}
    source_products={p['species_id']:float(p['stoichiometry']) for p in json.loads(source_by[r['sbml_reaction_id']]['products_json'])}
    assert reactants==source_reactants
    assert products==source_products
    reactant_sinks.update(s for s in reactants if s in sinks)
    delta=Counter()
    for s,v in products.items(): delta[s]+=float(v)
    for s,v in reactants.items(): delta[s]-=float(v)
    assert float(r['net_tracked_particle_count_per_event'])==sum(delta.values())
    for key in free_keys: assert float(r[key])==delta[key[len('net_free_'):]]
assert not reactant_sinks
for s in sinks:
    line=next(line for line in detail.splitlines() if re.match(r'^\|\s*\d+\s*\|\s*`'+re.escape(s)+r'`',line))
    assert 'cumulative' in line

assert all(r['decision_status']=='PENDING' for r in decisions)
assert count(r['candidate_label'] for r in decisions)=={'DROP_CANDIDATE':388,'KEEP':202,'LUMP_CANDIDATE':378}
assert all(r['HUMAN_REVIEW_REQUIRED'].lower()=='true' for r in decisions if r['candidate_label']!='KEEP')
review=(root/'docs/reduction/human_reduction_review.md').read_text(encoding='utf-8')
checked=re.findall(r'^- \[[xX]\]',review,re.M)
unchecked=re.findall(r'^- \[ \] (.+)$',review,re.M)
assert not checked and unchecked
resource_manifest=load('models/pnas2017_full_reference/audit/resource_map_manifest.json')
verified_hashes={}
for section in ['input_sha256','output_sha256']:
    for p,digest in resource_manifest[section].items():
        got=hashlib.sha256((root/p).read_bytes()).hexdigest()
        assert got==digest,(p,got,digest)
        verified_hashes[p]=got
result={'repository_head':'678fcb709324142454fd7a80cb6185c64b900510','method':'Independent CSV/JSON/Markdown cross-check against existing repository inventories; no second SBML parser; no generator runs','annotation':annotation,'species_contract':{'status':'HUMAN_APPROVED_V1 documented in summary/detailed/sync','class_counts':count(cls.values()),'summary_and_detail_and_source_exact_match':True,'machine_source_map_rows':len(smap),'machine_source_map_scope':'v3 candidate navigation; final I/II-A/II-B/III/C classes reside in approved Markdown contract and existing structural verifier'},'resource_ledger':{'species_properties_rows':len(props),'reaction_balance_rows':len(balance),'resources_distinct_and_Class_I':resources,'peptidyl_tRNA_II_B':['Pept0002tRNAGlyGCC','Pept0003tRNAGlyGCC'],'terminal_sink_count':len(sinks),'sink_consumption_reactions':0,'formula_net_charge_protonation_blank_rows':len(props),'Mg_binding':'No invented value; absent metadata explicitly disables all 968 ionic_strength_status fields','unit_status_counts':count(r['reference_initial_unit_status'] for r in props),'positive_reference_initial_components':27,'elemental_balance_status_counts':count(r['elemental_balance_status'] for r in balance),'moiety_balance_status_counts':count(r['moiety_balance_status'] for r in balance),'ionic_strength_status_counts':count(r['ionic_strength_status'] for r in balance),'all_event_free_resource_and_particle_deltas_recomputed':True,'free_resource_delta_columns':free_keys},'reduction_review':{'decision_status_counts':count(r['decision_status'] for r in decisions),'candidate_labels':count(r['candidate_label'] for r in decisions),'checked_process_boxes':len(checked),'unchecked_process_boxes':len(unchecked),'unchecked_choices':count(unchecked)},'resource_manifest_verified_sha256':verified_hashes,'overall':'PASS','scientific_boundary':'Information retention and annotation/ledger consistency only; no QSSA/lumping/kinetic equivalence or reduced-model validation'}
(out/'independent_contracts_evidence.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2,ensure_ascii=False))

