# G1-PNAS contracts and resource-ledger read-only audit

Basis: current main checkout `C:\Users\sean\.codex\worktrees\g1-pnas-closure\GUV` at `678fcb709324142454fd7a80cb6185c64b900510`. Python 3.12.4 (`D:\Code\Anaconda\python.exe`). No repository file was edited and no generator was run by this audit. Only current-main tracked artifacts were used; no research-branch evidence was imported.

## Verification commands

| Exact command (checkout working directory) | Exit | Result |
| --- | ---: | --- |
| `python scripts/verify_reaction_level_annotation.py` | 0 | Existing v1 verifier plus invoked v2 verifier pass. |
| `python scripts/verify_reaction_level_annotation_v2.py` | 0 | Current functional annotation/source/hash/contracts pass. |
| `python scripts/verify_reaction_level_contract.py` | 0 | Source counts, 23-stage vocabulary, reverse-pair and source-coverage checks pass. |
| `python scripts/verify_species_information_contract.py` | 0 | Exact-once species coverage, approved class tally, source rules and protected resources pass. |
| `python C:\Users\sean\.codex\tmp\g1-pnas-20261002\contracts\independent_contracts_check.py` | 1 initially, 0 after temp-diagnostic representation correction | Initial assertion compared resource-ledger JSON dictionaries with inventory JSON lists rather than their common ID/coefficient representation; corrected only the temporary script, reran successfully, retained `independent_contracts_check.first_attempt.log`. This was not a scientific verifier failure. |

There is no standalone annotation-v0 verifier on current main. Its preserved 968-row table/manifest was independently checked in the diagnostic: exact original inventory IDs once each, source stage/CellDesigner/confidence counts, 580 directed reverse-pair rows, 388 DEG rows, reciprocal pair stages and the two low-confidence source IDs agree.

## Machine evidence

`independent_contracts_evidence.json` records the independently derived results and verified resource-map hashes.

- Annotation v0/v1/v2: each contains all 968 source inventory IDs exactly once, with nonempty original Level-A/Level-B provenance. v2 counts: DIRECT_CHEMISTRY 492; GRAPH_PROPAGATED 50; HUMAN_REVIEW_REQUIRED 0; REFERENCE_DISABLED 420; SHARED_JUNCTION 6. Live functional review queue 0, unresolved 0. There are 36 family rows (35 active families + RFAM_DEG). Existing verifier tests source fields, 290 reciprocal reverse pairs, human-approved local rules and retained non-target scientific fingerprints.
- Species contract: normative approved summary and numbered detailed tables independently agree with each other and all 241 source inventory IDs exactly once. Counts I=42, II-A=57, II-B=91, III=22, C=29. Both tables and human_audit_sync explicitly document human approval. No factual mismatch was found. The machine-readable `species_reduction_map.csv/json` remains v3 candidate navigation; the final I/II-A/II-B/III/C classification is the approved Markdown information contract checked by the existing structural verifier. The candidate-map taxonomy must not be mistaken for a competing human decision.
- Resource IDs remain distinct: ATP/ADP/AMP/GTP/GDP/GMP/PO4/PPi/CP/Cr, Gly/Met/fMet, uncharged and charged tRNAs, ribosomal subunits/70S, translation factors, GlyRS/MetRS, CK/MK/NDK/PPiase, mRNA and Pept0003. These resources are Class I. No generic NTP/NXP species replaces them. Pept0002 and the two free peptidyl-tRNA pools are II-B; bound factor/ribosome/tRNA occupancy obligations remain in the approved contract.
- All 29 Class-C sinks are non-feedback in current source inventory (no reaction consumes a Class-C sink), and every detailed sink row requires cumulative loss accounting. Class III permits loss of microscopic elongation identity while retaining declared elongation flux/occupancy and peptide/tRNA/ribosome/resource information.
- `species_properties.csv`: 241 unique source IDs. Formula, net_charge and charge_protonation_convention are blank in all 241 rows; formula_charge_provenance is UNRESOLVED. All 241 reference-unit statuses explicitly say uM is inferred from paper examples and the author CSV omits unit metadata. Positive reference initial components = 27.
- `reaction_balance_audit.csv`: 968 unique source IDs. All event-level represented-particle deltas and 18 free-resource delta columns were recomputed from existing original reaction inventory stoichiometries and agree. All 968 elemental-balance statuses are UNRESOLVED_FORMULAS_ABSENT; all 968 moiety-balance statuses are UNRESOLVED_BOUND_MOIETIES_NOT_ANNOTATED; all 968 ionic-strength statuses are UNAVAILABLE_CHARGE_PROTONATION_MG_BINDING_ABSENT. No formula/charge/protonation/Mg value was invented. The ledger documents a represented-species ideal particle proxy, not validated osmotic pressure or whole-system quantitative ionic strength.
- Reduction choices: 968/968 decision_status=PENDING. Candidate labels KEEP 202, LUMP_CANDIDATE 378, DROP_CANDIDATE 388. Non-KEEP rows explicitly require human review. Human process review contains 96 empty boxes (6 choices x 16 cards), zero selected. KEEP labels remain candidate guidance with decision_status=PENDING. No kinetic transformation approval follows from functional annotation or the species information contract.

## Resource-map manifest identities verified from bytes

- canonical original SBML: dc43bcec367f52105fe8d1ba328e59b064935df5faf8f880e078b212a40183df
- raw SBML_files.zip: 24f0748c883eb6dcb748c20de7fdb2c8e495397f4b8ffb6c82246a03f0a93b03
- raw Simulate_fMGG_synthesis.zip: beb27ebbd314133fbd83f68dcf8ad2ebe08cb16a1adda170b6b7b408ad355b52
- species_properties.csv: fcb2ade0d390ec8b08ba3a613a96dfe4ff801b3324f362360534fd504f7ad9d8
- reaction_balance_audit.csv: 89c7c5710b4ee46cc2da44442ba49fcc8c3c546289ad4521b11fc50a82eb3962
- reduction_decisions.csv: 70fd3f98de5056a1a63c29db58d310ec5986d4c52b6bfcbae9634b38e2e8d7f8

## Scope boundaries

Class I protects output trajectories and need not imply independent ODE coordinates. Class II-A allows reconstruction in principle and does not prove QSSA. II-B protects declared functional occupancy/pools; III protects aggregate/resource obligations; C protects cumulative losses. The completed 968-row functional annotation does not approve QSSA, lumping, deletion, chemostats, fast equilibrium, kinetic equivalence or reduced-core validation. The older v0 vocabulary/first-pass and v1 provisional graph statements are retained versioned layers, superseded for current functional status by v2, not evidence that current functional annotation remains unresolved.
